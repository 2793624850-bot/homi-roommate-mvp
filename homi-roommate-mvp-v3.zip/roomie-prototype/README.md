# 合住 Homi — 合租生活管家 MVP

纯静态交互原型，无需构建步骤。直接部署整个目录即可。

## Vercel
1. 新建项目并上传本目录，或推送到 GitHub 后 Import。
2. Framework Preset 选 Other；无需 Build Command；Output Directory 留空。
3. 部署后在 Project Settings > Domains 保留项目的 `*.vercel.app` 域名。
4. 后续 48h 只更新同一个 Project，不删除/重建项目，域名即可保持不变。

## 验收
- 首页、账单、值日、公共物品、室友公约 5 个页面均可切换。
- “完成 / 支付 / 认领 / 提醒 / 新增”均有交互反馈。
- 手机和桌面响应式布局。
